#include <stdio.h>
#include "apue.h"

void accumulation(int d_sum);

int main()
{
	FILE *sum;
	int total_sum = 0;
	pid_t pid[5];
	pid_t pd;
	int year = 5, week = 52, day = 7;

	sum = fopen("sum.txt", "w");
	fprintf(sum, "%d\n", 0);
	fclose(sum);

	TELL_WAIT();

	for (int i = 0; i < 5; i++)
	{
		pid[i] = fork();
		if (pid[i] <= 0)
			break;
	}
	for(int i=0;i<5;i++)
	{
	if (pid[i] < 0)
	{
		err_sys("fork error");
	}
	else if (pid[i] == 0)
	{
		for (int j = 1; j <= 52; j++)
		{
			char name[128];
			FILE *ds;
			if (j < 10)
			{
				sprintf(name, "%d-0%d.txt", i+1, j);
			}
			else
			{
				sprintf(name, "%d-%d.txt", i+1, j);
			}
			ds = fopen(name, "r");
			for (int q = 0; q < 7; q++)
			{
				int d_sum = 0;
				for (int k = 0; k < 96; k++)
				{
					int tmp = 0;
					fscanf(ds, "%d", &tmp);
					d_sum += tmp;
				}

				WAIT_PARENT();
				accumulation(d_sum);
				TELL_PARENT(getppid());
			}
		}
		exit(0);
	}
	else continue;
	}
	//parent
	
		for (int i = 0; i < 5; i++)
		{
			for (int j = 1; j <= 52; j++)
			{
				for (int q = 0; q < 7; q++)
				{
					TELL_CHILD(pid[i]);
					WAIT_CHILD();
				}
			}
		}
	
	

	sum = fopen("sum.txt", "r");
	fscanf(sum, "%d", &total_sum);
	printf("Day_Average = %d\n", total_sum / (year * week * day));
	fclose(sum);

	return 0;
}

void accumulation(int d_sum) //Accumulating the daily sum to "sum.txt".
{
	FILE *sum;
	int tmp = 0;

	sum = fopen("sum.txt", "r+");
	fscanf(sum, "%d", &tmp);

	tmp += d_sum;

	rewind(sum);
	fprintf(sum, "%d", tmp);
	fclose(sum);

	return;
}

/*
#include <stdio.h>
#include "apue.h"

void accumulation(int d_sum);

int main()
{
	FILE *sum;
	int total_sum = 0;
	pid_t pid[5];
	int year = 5, week = 52, day = 7;

	sum = fopen("sum.txt", "w");
	fprintf(sum, "%d\n", 0);
	fclose(sum);

	
	TELL_WAIT();
	for (int i = 1; i <= 5; i++)
	{
		if ((pid[i - 1] = fork()) < 0)
			err_sys("fork error");
		else if (pid[i - 1] == 0) //child
		{
			for (int j = 1; j <= 52; j++)
			{
				char name[128];
				FILE *ds;
				if (j < 10)
				{
					sprintf(name, "%d-0%d.txt", i, j);
				}
				else
				{
					sprintf(name, "%d-%d.txt", i, j);
				}
				ds = fopen(name, "r");
				for (int q = 0; q < 7; q++)
				{
					int d_sum = 0;
					for (int k = 0; k < 96; k++)
					{
						int tmp = 0;
						fscanf(ds, "%d", &tmp);
						d_sum += tmp;
					}
					
					WAIT_PARENT();
					accumulation(d_sum);
					TELL_PARENT(getppid());
				}
			}
			exit(0);
		}
		else //parent
		{
			for (int j = 1; j <= 52; j++)
			{
				for (int q = 0; q < 7; q++)
				{
					TELL_CHILD(pid[i]);
					WAIT_CHILD();
				}
			}
		}
	}

	sum = fopen("sum.txt", "r");
	fscanf(sum, "%d", &total_sum);
	printf("Day_Average = %d\n", total_sum / (year * week * day));
	fclose(sum);

	return 0;
}

void accumulation(int d_sum) //Accumulating the daily sum to "sum.txt".
{
	FILE *sum;
	int tmp = 0;

	sum = fopen("sum.txt", "r+");
	fscanf(sum, "%d", &tmp);

	tmp += d_sum;

	rewind(sum);
	fprintf(sum, "%d", tmp);
	fclose(sum);

	return;
}


*/